package com.example.chris.fitnessapplication.data.Users;

import android.app.Application;


public class RequiredUserDependency extends Application {

    @Override
    public void onCreate(){
        super.onCreate();
    }
}
